Exact unmodified sources of MPL-2.0 Rust crates used by Yeran 1.0. Sources retain MPL-2.0, independently of Yeran's MIT license. See Cargo.lock for registry checksums.
